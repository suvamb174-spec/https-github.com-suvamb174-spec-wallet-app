import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Replace YOUR_GITHUB_USERNAME and YOUR_REPO_NAME below
// e.g. if your repo URL is github.com/john/wallet-app
//      set base: '/wallet-app/'
export default defineConfig({
  plugins: [react()],
  base: '/wallet-app/',
})
