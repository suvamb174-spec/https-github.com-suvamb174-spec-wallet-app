import React, { useState, useMemo } from "react";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  PieChart, Pie, Cell,
} from "recharts";
import { ShieldCheck, AlertTriangle, ArrowUpRight, ArrowDownLeft, Send, Plus, Eye, EyeOff, Lock } from "lucide-react";

const ink = "#11161F";
const paper = "#F6F3EC";
const moss = "#2F5D4E";
const signal = "#B3432B";
const gold = "#C8A24A";
const line = "#D8D2C2";

const txns = [
  { id: 1, name: "Priya Raman", note: "Dinner split", amount: -820, time: "Today, 8:14 PM", type: "out" },
  { id: 2, name: "Salary — Initech", note: "Monthly payroll", amount: 64000, time: "Today, 9:02 AM", type: "in" },
  { id: 3, name: "Arun K", note: "Cab fare", amount: -240, time: "Yesterday, 6:40 PM", type: "out" },
  { id: 4, name: "Unknown device", note: "Login attempt — Mumbai", amount: 0, time: "Yesterday, 3:11 PM", type: "alert" },
  { id: 5, name: "Meena S", note: "Rent contribution", amount: -12500, time: "27 Jun, 11:00 AM", type: "out" },
  { id: 6, name: "Refund — Bluewave", amount: 1499, note: "Order #4482", time: "25 Jun, 2:30 PM", type: "in" },
];

const weekly = [
  { d: "Mon", in: 0, out: 1200 },
  { d: "Tue", in: 0, out: 450 },
  { d: "Wed", in: 64000, out: 820 },
  { d: "Thu", in: 1499, out: 240 },
  { d: "Fri", in: 0, out: 12500 },
  { d: "Sat", in: 0, out: 0 },
  { d: "Sun", in: 0, out: 600 },
];

const categories = [
  { name: "Transfers", value: 13320, color: moss },
  { name: "Food", value: 1020, color: gold },
  { name: "Transport", value: 240, color: "#7A8FA6" },
  { name: "Other", value: 600, color: signal },
];

function fmt(n) {
  const sign = n < 0 ? "-" : "";
  return sign + "₹" + Math.abs(n).toLocaleString("en-IN");
}

export default function Wallet() {
  const [hideBalance, setHideBalance] = useState(false);
  const [twoFA, setTwoFA] = useState(true);
  const [tab, setTab] = useState("activity");
  const balance = 84219;

  const dismissedAlert = txns.find((t) => t.type === "alert");
  const [alertOpen, setAlertOpen] = useState(!!dismissedAlert);

  return (
    <div style={{ fontFamily: "'Inter', system-ui, sans-serif", background: paper, minHeight: "100vh", color: ink, padding: "32px 16px" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap');
        .num { font-family: 'Space Mono', monospace; font-variant-numeric: tabular-nums; }
        .card { background: #fff; border: 1px solid ${line}; border-radius: 14px; }
        .btn { border: none; cursor: pointer; font-family: inherit; transition: transform .15s ease, opacity .15s ease; }
        .btn:active { transform: scale(0.97); }
        .row:hover { background: #FAF8F2; }
      `}</style>

      <div style={{ maxWidth: 880, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 30, height: 30, borderRadius: 8, background: ink, display: "grid", placeItems: "center" }}>
              <span style={{ color: gold, fontWeight: 700, fontSize: 14, fontFamily: "'Space Mono', monospace" }}>L</span>
            </div>
            <span style={{ fontWeight: 700, fontSize: 18, letterSpacing: "-0.01em" }}>Ledger</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: moss, fontWeight: 600 }}>
            <ShieldCheck size={16} />
            {twoFA ? "2FA active" : "2FA off"}
          </div>
        </div>

        {/* Fraud alert */}
        {alertOpen && (
          <div className="card" style={{ borderColor: signal, background: "#FBEDE9", padding: "14px 16px", marginBottom: 16, display: "flex", alignItems: "center", gap: 12 }}>
            <AlertTriangle size={20} color={signal} style={{ flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Unusual login flagged</div>
              <div style={{ fontSize: 13, color: "#5a5650" }}>New device tried signing in from Mumbai. If that wasn't you, secure your account now.</div>
            </div>
            <button className="btn" style={{ background: signal, color: "#fff", padding: "8px 14px", borderRadius: 8, fontSize: 13, fontWeight: 600 }}>Review</button>
            <button className="btn" onClick={() => setAlertOpen(false)} style={{ background: "transparent", color: "#8a8579", fontSize: 13 }}>Dismiss</button>
          </div>
        )}

        {/* Balance hero */}
        <div className="card" style={{ padding: 28, marginBottom: 16, background: ink, borderColor: ink, color: paper, position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", right: -40, top: -40, width: 180, height: 180, borderRadius: "50%", background: "rgba(200,162,74,0.12)" }} />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ fontSize: 13, color: "#A8A398", marginBottom: 6 }}>Available balance</div>
              <div className="num" style={{ fontSize: 40, fontWeight: 700, letterSpacing: "-0.01em" }}>
                {hideBalance ? "₹ • • • • • •" : fmt(balance)}
              </div>
            </div>
            <button className="btn" onClick={() => setHideBalance(!hideBalance)} style={{ background: "rgba(255,255,255,0.1)", color: paper, padding: 8, borderRadius: 8 }}>
              {hideBalance ? <Eye size={16} /> : <EyeOff size={16} />}
            </button>
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
            <button className="btn" style={{ background: gold, color: ink, padding: "10px 16px", borderRadius: 9, fontWeight: 600, fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}>
              <Send size={14} /> Send
            </button>
            <button className="btn" style={{ background: "rgba(255,255,255,0.1)", color: paper, padding: "10px 16px", borderRadius: 9, fontWeight: 600, fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}>
              <Plus size={14} /> Top up
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, marginBottom: 14, borderBottom: `1px solid ${line}` }}>
          {["activity", "analytics", "security"].map((t) => (
            <button key={t} className="btn" onClick={() => setTab(t)}
              style={{ background: "transparent", padding: "10px 4px", marginRight: 22, fontSize: 14, fontWeight: 600, color: tab === t ? ink : "#9a9586", borderBottom: tab === t ? `2px solid ${moss}` : "2px solid transparent", borderRadius: 0, textTransform: "capitalize" }}>
              {t}
            </button>
          ))}
        </div>

        {tab === "activity" && (
          <div className="card">
            {txns.filter(t => t.type !== "alert").map((t, i) => (
              <div key={t.id} className="row" style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 18px", borderBottom: i < txns.length - 2 ? `1px solid ${line}` : "none" }}>
                <div style={{ width: 36, height: 36, borderRadius: "50%", background: t.type === "in" ? "#E7F0EB" : "#F1EEE6", display: "grid", placeItems: "center", flexShrink: 0 }}>
                  {t.type === "in" ? <ArrowDownLeft size={16} color={moss} /> : <ArrowUpRight size={16} color={ink} />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{t.name}</div>
                  <div style={{ fontSize: 12.5, color: "#8a8579" }}>{t.note} · {t.time}</div>
                </div>
                <div className="num" style={{ fontWeight: 700, fontSize: 14, color: t.amount > 0 ? moss : ink }}>
                  {t.amount > 0 ? "+" : ""}{fmt(t.amount)}
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "analytics" && (
          <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
            <div className="card" style={{ padding: "18px 18px 6px" }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8 }}>This week's flow</div>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={weekly}>
                  <defs>
                    <linearGradient id="in" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={moss} stopOpacity={0.35} />
                      <stop offset="100%" stopColor={moss} stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="out" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={signal} stopOpacity={0.3} />
                      <stop offset="100%" stopColor={signal} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={line} vertical={false} />
                  <XAxis dataKey="d" tick={{ fontSize: 12, fill: "#8a8579" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "#8a8579" }} axisLine={false} tickLine={false} width={50} />
                  <Tooltip formatter={(v) => fmt(v)} contentStyle={{ fontSize: 12, borderRadius: 8, border: `1px solid ${line}` }} />
                  <Area type="monotone" dataKey="in" stroke={moss} fill="url(#in)" strokeWidth={2} />
                  <Area type="monotone" dataKey="out" stroke={signal} fill="url(#out)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="card" style={{ padding: 18 }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8 }}>Spend by category</div>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={categories} dataKey="value" nameKey="name" innerRadius={45} outerRadius={70} paddingAngle={3}>
                    {categories.map((c, i) => <Cell key={i} fill={c.color} />)}
                  </Pie>
                  <Tooltip formatter={(v) => fmt(v)} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display: "grid", gap: 6, marginTop: 4 }}>
                {categories.map((c) => (
                  <div key={c.name} style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5 }}>
                    <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ width: 8, height: 8, borderRadius: "50%", background: c.color, display: "inline-block" }} />
                      {c.name}
                    </span>
                    <span className="num" style={{ color: "#5a5650" }}>{fmt(c.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === "security" && (
          <div className="card" style={{ padding: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0", borderBottom: `1px solid ${line}` }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <Lock size={18} color={moss} />
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>Two-factor authentication</div>
                  <div style={{ fontSize: 12.5, color: "#8a8579" }}>Require a one-time code on every new device</div>
                </div>
              </div>
              <button className="btn" onClick={() => setTwoFA(!twoFA)}
                style={{ width: 44, height: 26, borderRadius: 13, background: twoFA ? moss : "#D8D2C2", position: "relative" }}>
                <span style={{ position: "absolute", top: 3, left: twoFA ? 21 : 3, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s ease" }} />
              </button>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0" }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <AlertTriangle size={18} color={gold} />
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>Fraud alerts</div>
                  <div style={{ fontSize: 12.5, color: "#8a8579" }}>Notify me of unusual logins or transactions</div>
                </div>
              </div>
              <span style={{ fontSize: 12.5, fontWeight: 600, color: moss }}>On</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
