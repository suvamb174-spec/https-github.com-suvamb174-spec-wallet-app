# 💳 Ledger — Digital Wallet UI

A production-ready React + Vite digital wallet front-end featuring wallet
balance, transaction history, 2FA, fraud detection alerts, and payment analytics.

🌐 **Live demo:** `https://YOUR_GITHUB_USERNAME.github.io/wallet-app/`

---

## 🚀 Run locally

```bash
git clone https://github.com/YOUR_GITHUB_USERNAME/wallet-app.git
cd wallet-app
npm install
npm run dev
```

Open http://localhost:5173

---

## ☁️ Deploy to GitHub Pages (one-time setup)

1. **Create the repo on GitHub**
   - Go to https://github.com/new
   - Name it `wallet-app` (must match `base` in `vite.config.js`)
   - Leave it empty (no README)

2. **Edit `vite.config.js`** — set your repo name:
   ```js
   base: '/wallet-app/',  // change if repo name differs
   ```

3. **Push your code**
   ```bash
   git init
   git add .
   git commit -m "initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/wallet-app.git
   git branch -M main
   git push -u origin main
   ```

4. **Enable GitHub Pages**
   - Go to your repo → **Settings → Pages**
   - Under **Source** select **GitHub Actions**
   - Save

5. ✅ Every push to `main` auto-deploys. Watch it under the **Actions** tab.

---

## 📁 Project structure

```
wallet-app/
├── .github/
│   └── workflows/
│       └── deploy.yml       ← GitHub Actions CI/CD
├── src/
│   ├── App.jsx              ← Wallet UI (balance, txns, analytics, security)
│   └── main.jsx             ← React entry point
├── index.html
├── vite.config.js           ← set base: '/your-repo-name/'
└── package.json
```

---

## ✨ Features

| Feature | Status |
|---|---|
| Wallet balance (hide/show) | ✅ |
| Transaction history | ✅ |
| Fraud detection alert | ✅ |
| Two-factor auth toggle | ✅ |
| Weekly cash-flow chart | ✅ |
| Spend-by-category pie | ✅ |
| GitHub Pages auto-deploy | ✅ |

---

## 🔮 Next steps (backend)

- Node.js + Express REST API
- PostgreSQL schema: `users`, `wallets`, `transactions`
- Real 2FA via Twilio Verify
- Payment gateway: Stripe or Razorpay
